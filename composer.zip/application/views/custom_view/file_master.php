
<script src="<?php echo base_url(); ?>assets/themplate/assets/libs/ckfinder/ckfinder.js"></script>
<script>
	var finder;

	CKFinder.start( {
		onInit: function( instance ) {
			finder = instance;
		}
	} );
</script>